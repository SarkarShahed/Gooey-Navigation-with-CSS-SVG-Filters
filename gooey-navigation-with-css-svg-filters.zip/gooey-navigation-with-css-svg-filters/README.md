# Gooey Navigation with css/svg filters

A Pen created on CodePen.io. Original URL: [https://codepen.io/simeydotme/pen/LYLxJqV](https://codepen.io/simeydotme/pen/LYLxJqV).

Using svg filter, and css to make a menu with a neat bouncey gooey effect on hover.